package com.cg.bank.dao;

import com.cg.bank.dto.Customer;

public interface BankAccountDAO {

	public Customer createAccount(Customer customer);
	
	public Customer checkBalance(String mobileNo);
	
	public void updateBalance(String mobileNo, double amount);

	Customer findCustomer(String mobileNo);
	
	
}