package com.cg.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankAccountException;

public class BankAccountDAOImpl implements BankAccountDAO{
	EntityManager manager;

	public BankAccountDAOImpl() throws BankAccountException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		manager = emf.createEntityManager();
	}

	@Override
	public Customer createAccount(Customer customer) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		manager.persist(customer);
		manager.getTransaction().commit();
		return customer;

	}

	@Override
	public Customer checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		Customer customer=manager.find(Customer.class, mobileNo);
		manager.getTransaction().commit();
		return customer;
	}

	@Override
	public void updateBalance(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		Query query=manager.createQuery("Update Customer SET amount=:bal where mobile=:mob");
		query.setParameter("bal", amount);
		query.setParameter("mob", mobileNo);
		manager.getTransaction().commit();
		
	}

	@Override
	public Customer findCustomer(String mobileNo) {
			// TODO Auto-generated method stub
		manager.getTransaction().begin();
		 Customer customer = manager.find(Customer.class, mobileNo);
		manager.getTransaction().commit();
			return customer;
	}
}
