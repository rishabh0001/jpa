package com.cg.bank.service;

import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankAccountException;

public interface BankAccountService {

	public void createAccount(Customer customer);
	
	public Customer deposit(String mobileNo, double amount) throws BankAccountException;
	
	public Customer withdraw(String mobileNo, double amount) throws BankAccountException;
	
	public String checkBalance(String mobileNo);
	
	public void fundTransfer(String sender, String reciever, double amount) throws BankAccountException;
	
	
	public boolean validateAccount(String mobileNo) throws BankAccountException;
	
	public boolean validateName(String name) throws BankAccountException;
	
	public boolean validateAge(float age) throws BankAccountException;
	
	public boolean validateMobileNo(String mobileNo) throws BankAccountException;
	
	public boolean validateAmount(double amount) throws BankAccountException;
			
}
