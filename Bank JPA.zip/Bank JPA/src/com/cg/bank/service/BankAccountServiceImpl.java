package com.cg.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankAccountDAO;
import com.cg.bank.dao.BankAccountDAOImpl;
import com.cg.bank.dto.Customer;
import com.cg.bank.exception.BankAccountException;


public class BankAccountServiceImpl implements BankAccountService{

	BankAccountDAO dao;
	public BankAccountServiceImpl() throws BankAccountException{
	dao  = new BankAccountDAOImpl();
	}

	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		dao.createAccount(customer);		
	}

	@Override
	public Customer deposit(String mobileNo, double amount) throws BankAccountException {
		// TODO Auto-generated method stub
		Customer customer = dao.findCustomer(mobileNo);
		if (amount > 0) {
				double bal = customer.getInitialBalance();
				bal += amount;
				customer.setInitialBalance(bal);;
				System.out.println(amount + " Deposited \n Balance : " + customer.getInitialBalance());
				dao.updateBalance(mobileNo, bal);
				return customer;
		}
		else 
				throw new BankAccountException("Amount should be positive");
}

	@Override
	public Customer withdraw(String mobileNo, double amount) throws BankAccountException {
		// TODO Auto-generated method stub
		Customer customer = dao.findCustomer(mobileNo);
		if(amount > 0) {
				if((customer.getInitialBalance() - amount) >= 0)
				{		
						double bal = customer.getInitialBalance();
						bal -= amount;
						customer.setInitialBalance(bal);;
						System.out.println(amount + " Withdrawn \n Balance : " + customer.getInitialBalance());
						dao.updateBalance(mobileNo, bal);
						return customer;
				}
				else 
						throw new BankAccountException("Balance is not sufficient for this withdrawl amount");
		}
		else 
				throw new BankAccountException("Amount cannot be Negative ");
}

	@Override
	public String checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		Customer customer = dao.checkBalance(mobileNo);
		return customer.toString();
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) throws BankAccountException {
		// TODO Auto-generated method stub
		Customer source = dao.findCustomer(sender);
		Customer target = dao.findCustomer(reciever);
		if (amount > 0) {
				if((source.getInitialBalance() - amount) >= 0)
				{	
						double bal1 = target.getInitialBalance();
						bal1 += amount;
						target.setInitialBalance(bal1);
						dao.updateBalance(reciever, bal1);
						double bal2 = source.getInitialBalance();
						bal2 -= amount;
						source.setInitialBalance(bal2);;
						dao.updateBalance(sender, bal2);
				}
				else {
						throw new BankAccountException("Balance should be higher than amount to be transferred !!!! ");
				}
		}
		else 
				System.out.println("Amount should be positive to send");
}

	@Override
	public boolean validateName(String name) throws BankAccountException {
		// TODO Auto-generated method stub
		if(name == null)
			throw new BankAccountException("Null value found");
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{1,15}[ ][A-Z]{1}[a-z]{1,15}");
		Matcher m = p.matcher(name); 
		if(!m.matches())
			System.out.println("-----WARNING----Name invalid!\nShould Start with Capital letter rest of the letters in small letters\nEnter your first & last name.---Rishab Srivastava----");
		return m.matches();
		
	}

	@Override
	public boolean validateAge(float age)  throws BankAccountException {
		try{
			// TODO Auto-generated method stub
			if(age == 0)
				throw new BankAccountException("-----WARNING----\nAge cannot be  null");
			else if(age >100)
				throw new BankAccountException("-----WARNING----\nAge cannot be  greater than 100");
			else if(age < 0)
				throw new BankAccountException("-----WARNING----\nAge cannot be a negative number");
			else if(age >17)
				return true;
			
		
	} catch (BankAccountException e) {
		// TODO Auto-generated catch block
		System.out.println(e);
	}
		return false;
	}

	@Override
	public boolean validateMobileNo(String mobileNo) throws BankAccountException{
		try{
			// TODO Auto-generated method stub
			if(mobileNo == null)
				throw new BankAccountException("Null value found");
			Pattern p = Pattern.compile("[6-9][0-9]{9}");
			Matcher m = p.matcher(mobileNo);
			if(!m.matches())
				System.out.println("-----WARNING----Mobile Number Invalid!\nShould start either 6,7,8 or 9 and should be a 10-digit number & Should not be null");
			return m.matches();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return false;
	}

	@Override
	public boolean validateAmount(double amount) throws BankAccountException {
		// TODO Auto-generated method stub
		if(amount == 0)
			throw new BankAccountException("----WARNING----Null value found");
		String am = String.valueOf(amount);
		if(!am.matches("\\d{1,7}\\.\\d{0,2}"))
			System.out.println("-----WARNING----Invalid Amount!\nShould be greater than 0");
		return (am.matches("\\d{1,7}\\.\\d{0,2}"));
	}

	@Override
	public boolean validateAccount(String mobileNo) throws BankAccountException {
		// TODO Auto-generated method stub
		Customer customer = dao.findCustomer(mobileNo);
		if(customer == null)
			return false;
		return true;
	}
	}

